<?php 
      // Initialize the session
  session_start();
   
  // Check if the user is logged in, if not then redirect him to login page
  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
      header("location: authentication/login.php");
      exit;
  }
?>

<?php require('templatefile/header.php');?>
<title>Помощ</title>

    <style>
    
        div {
            text-align: center;
        }
        div.div-img {
            text-align: left;
        }

    </style>

<?php require('templatefile/container.php');?>
<div class="help-div">
    <div clas="help-text">
        <h2>Тази страница ще ви помогне да разберете как се работи с конвертора на валута</h2>
        <br><br><br>
    </div>
    <div class="div-img">
        <h3>1. Изберете от падащото меню желаната от вас валута за конвертиране:</h3>
        <img src="img/help-from-curr.png" width="900px"><br><br>
        <h3>2. Напишете в полето "Стойност:" желаната от вас стойност:</h3>
        <img src="img/help-amount.png" width="900px"><br><br>
        <h3>3. Изберете от падащото меню желаната от вас валута, в която да се новертира:</h3>
        <img src="img/help-conv-to.png" width="900px"><br><br>
        <h3>4. Резултата може да бъде видян в полето "Конвертирана стойност:"</h3>
        <img src="img/help-conv-amount.png" width="900px">
 </div>

</div>